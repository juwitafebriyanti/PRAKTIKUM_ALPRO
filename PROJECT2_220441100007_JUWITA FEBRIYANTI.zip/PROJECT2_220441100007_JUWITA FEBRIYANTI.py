# menentukan sebuah bilangan positif dan negatif
# a = int(input("Masukkan angka : "))
# if a > 0 :
#     print("Bilangan positif")
# elif a < 0 :
#     print("Bilangan negatif")
# else :
#     print("Bukan bilangan postif maupun negatif")

# # soal 2
# print(" ")
# c = int(input("Masukkan angka pertama : "))
# d = int(input("Masukkan angka kedua : "))
# if c > d :
#     print("c =", d, "d =", c)
# else :
#     print("c =", c, "d =", d)

# # permainan gunting batu kertas
print(" ")
x = ["gunting", "batu", "kertas"]
pemain1 = str(input("Pemain 1 : "))
pemain2 = str(input("Pemain 2 : "))

if pemain1 == pemain2 :
    print("seri")
elif pemain1 == "gunting" :
    if pemain2 == "kertas" :
        print("Pemain 1 menang dan pemain 2 kalah")
    else :
        print("pemain 2 menang dan pemain 1 kalah")
elif pemain1 == "batu" :
    if pemain2 == "kertas" :
        print("Pemain 2 menang dan pemain 1 kalah")
    else :
        print("pemain 1 menang dan pemain 2 kalah")
elif pemain1 == "kertas" :
    if pemain2 == "gunting" :
        print("Pemain 2 menang dan pemain 1 kalah")
    else :
        print("pemain 1 menang dan pemain 2 kalah")
else :
     print("Yang kamu masukkan salah")





