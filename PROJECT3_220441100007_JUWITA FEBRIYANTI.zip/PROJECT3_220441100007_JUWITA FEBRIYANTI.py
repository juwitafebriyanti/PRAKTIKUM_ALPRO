#  Soal 1

a = int(input("Masukkan angka : "))
for i in range(0, a) :
    for j in range(0, a - 1) :
        print('*', end = '')
    a -= 1
    print('')

# Soal 2

pilihan = "ya"

print("Selamat Datang Di Kalkulator Sederhana")
print("1. penjumlahan")
print("2. pengurangan")
print("3. perkalian")
print("4. pembagian")

while (input("Ketik ya untuk lanjut : ") == pilihan) :
    z = int(input("Masukkan pilihan operasi : "))
    x = int(input("Bilangan 1 : "))
    y = int(input("Bilangan 2 : "))

    if z == 1 :
        print(x, "+", y, "=", x+y)
    elif z == 2 :
        print(x, "-", y, "=", x-y)
    elif z == 3 :
        print(x, "*", y, "=", x*y)
    elif z == 4 :
        print(x, "/", y, "=", x/y)
    else :
        print("Yang Anda Masukkan Salah")

print("Selesai")