print("Soal 2")

# Himpunan bilangan prima
prima = {"2", "3", "5", "7", "11", "13", "17", "19", "23", "29"}
# Himpunan bilangan cacah
cacah = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"}

print("Bilangan Prima : ", prima)
print("Bilangan Cacah : ", cacah)
print("")

# union
print("Union : ", prima.union(cacah))
print("")

# intersection
print("Intersection :", prima.intersection(cacah))
print("")

# difference
a = prima.difference(cacah)
print("Difference a - b :" ,a)
b = cacah.difference(prima)
print("Difference b - a :" ,b)
print("")