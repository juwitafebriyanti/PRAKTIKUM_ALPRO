print("Soal 1")

def garis():
 print("_________________________")
Menu = {'Bakso': 10000,'Mie Ayam': 12000,'Mie Goreng': 8000,'Nasi Goreng': 10000,}
print(Menu)
garis()
print("")

nomor_meja = input("No meja : ")
pesanan = input("Pesanan anda : ")
harga = eval(input("Harga pesanan : "))
jumlah = eval(input("Jumlah pesanan anda : "))
total = harga * jumlah
print("total : ", total)
bayar = eval(input("Bayar : "))
kembalian = bayar - total
print("")

Data = {'no meja': nomor_meja, 'menu dipesan': pesanan, 'jumlah pesanan': jumlah, 'sub total': total, 'total dibayar': bayar , 'kembalian': kembalian }
print("Rincian : ", Data) 
print("")

kasir = "ya"
while input("ketik ya jika ingin merubah pesanan : ") == kasir:
    x = str(input("masukkan yang ingin dirubah : "))
    if x == "no meja":
        Data['no meja'] = str(input("Masukkan perubahan : "))
        print("Rincian : ", Data)
    elif x == "menu makanan":
        Data['menu pesanan'] = str(input("Masukkan perubahan : "))
        print("Rincian : ", Data)
    else:
        print("error")
else:
    print("Terima kasih")

print("")