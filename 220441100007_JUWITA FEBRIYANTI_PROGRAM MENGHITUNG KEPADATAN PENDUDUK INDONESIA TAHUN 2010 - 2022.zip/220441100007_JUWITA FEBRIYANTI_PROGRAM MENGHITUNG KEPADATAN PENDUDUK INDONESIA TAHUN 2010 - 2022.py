print('PROGRAM MENGHITUNG KEPADATAN PENDUDUK INDONESIA TAHUN 2010 - 2022')
print('-----------------------------------------------------------------')

def MasukkanData():
    # Luas wilayah Indonesia
    luasIndonesia = 1904569

    # Jumlah penduduk per tahun
    jumlahPendudukPerTahun = {
        '2010': 237641326,
        '2011': 241990500,
        '2012': 245425200,
        '2013': 248818100,
        '2014': 252164800,
        '2015': 255461700,
        '2016': 258705000,
        '2017': 261890900,
        '2018': 265015300,  
        '2019': 268074600,
        '2020': 270203900,
        '2021': 272682500,
        '2022': 275773800
    }

    def hitungKepadatan(penduduk, luasWilayah):
        kepadatan = penduduk / luasWilayah
        return kepadatan

    tahun = []

    i = 'y'
    while i == 'y':
        tahunYgDiinputUser = input('Masukkan tahun: ')
        tahun.append(tahunYgDiinputUser)

        i = input('Ketik "y" untuk mengulang: ')

    print('\nData kepadatan penduduk: ')
    for i in range (len(tahun)):
        tahunSekarang = tahun[i]
        jumlahPendudukSekarang = jumlahPendudukPerTahun[tahunSekarang]
        kepadatanSekarang = hitungKepadatan(jumlahPendudukSekarang, luasIndonesia)
        
        print('Jumlah penduduk tahun ' + tahunSekarang + ' = ' + str(jumlahPendudukSekarang))
        print('Jumlah kepadatan penduduk ' + tahunSekarang + ' = ' + str(kepadatanSekarang))

    edit = input('\nApakah data yang diinginkan sudah benar? (ketik "iya" jika sudah benar): ')
    if edit == 'iya':
        print('=============Program selesai==============')
        print(' ')
    elif edit == 'tidak':
        MasukkanData()
    else:
        print('Program eror')

MasukkanData()

