# Menghitung Harga Diskon Barang
harga = int(input("masukkan harga : "))
diskon = int(input("masukkan diskon : "))

rumus_diskon = harga * (diskon/100)
hasil = harga - rumus_diskon

print("Total harga setelah diskon = ", hasil)
print(" ")

# Menghitung nilai mata uang rupiah ke dollar dan sebaliknya
rupiah = float(input("masukkan nilai rupiah : "))
dollar = (rupiah / 15000)
print("Hasilnya = ", dollar)

print(" ")
dollar = float(input("masukkan nilai dollar : "))
rupiah = (dollar * 15000)
print("Hasilnya", rupiah)
