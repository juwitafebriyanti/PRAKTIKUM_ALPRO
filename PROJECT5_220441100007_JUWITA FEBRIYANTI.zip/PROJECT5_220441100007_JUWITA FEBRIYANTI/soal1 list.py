list1 = []
for a in range(15):
    list1.append(input("masukkan menu : "))
print(list1)
print((" "))
list2 = []
for a in range(5):
    list2.append(input("masukkan minuman : "))
print(list2)
print((" "))
list3 =[]
for a in range(5):
    list3.append(input("masukkan nama teman : "))
print(list3)
print((" "))
list4 =[]
for a in range (5):
    list4.append(input("masukkan bulan lahir : "))
print(list4)
print((" "))
list5 =[]
for a in range(5):
    list5.append(input("masukkan tanggal lahir : ")) 
print(list5)

print((" "))

i = "y"
while i == "y":
    menu = int(input("masukkan pilihan : "))
    if menu == 1 :
        del list1 [5:15]
        list1.extend(list4)
        print("menggabungkan list1 dan list4(list 1 berisi 5 menu makanan )=",list1)
    elif menu == 2 :
        list3[1] = "aku"
        list3[4] = "dia"
        print("update list3 index 1 dan index 4 =",list3)
    elif menu == 3 :
        del list5[1]
        del list5[3]
        print("hapus list5 index 1 dan index 4 =",list5)
    elif menu == 4 :
        list4.extend(list5)
        print("menggabungkan list 4 dan list 5 =",list4)
        print("minimumnya adalah",max(list4 + list5))
        print("maksimumnya adalah",min(list4 + list5))
    else:
        print("program yang anda masukkan salah")
    i = input("klik y untuk mengulang : ")