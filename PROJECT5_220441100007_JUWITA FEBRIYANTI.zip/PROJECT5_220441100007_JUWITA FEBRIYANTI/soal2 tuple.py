list1 = []
for a in range(5):
    list1.append(input("Masukkan nama kota : "))
tuple1 = tuple(list1)
print(tuple1)
print(" ")

# tuple2= ("12","20","23","31","19","30","45","98")
list2 = []
for a in range(8):
    list2.append(input("Masukkan angka: "))
tuple2 = tuple(list2)
print(tuple2)
print((" "))

# tuple3=('Pemograman', 'pEmograman', 'PeMograman', 'PemOgraman', 'pemoGraman')
list3 = []
for a in range(5):
    list3.append(input("Masukkan : "))
tuple3 = tuple(list3)
print(tuple3)
print((" "))

i = "y"
while i == "y":
    menu = int(input("Masukkan pilihan : "))
    if menu == 1 :
        a = tuple3[1]+ " "  + tuple3[3] + " " + tuple3[4] + " " + tuple1[1] + " " + tuple1[3]
        print("Gabungan tuple 1 dan tuple 3 = ", a)
    elif menu == 2 :
        i = tuple2[2]+ " " +tuple2[4]
        b = 5
        print(("tampilan tuple2 index 2 dan index 4 sebanyak 5 kali = "))
        for a in range(b):
            print(i)

    else :
        print(("Yang anda masukkan salah"))
    i = input(("ketik y untuk mengulang program : "))
print(("Program selesai"))


