# Soal 1
print("Konversi Suhu")

pilihan = "ya"

def celcius(c):
    rea = c * 4/5
    fahr = (c * 9/5)+32
    kel = c + 275
    print("celcius dalam reamur : ", rea)
    print("celcius dalam fahrenheit : ", fahr)
    print("celcius dalam kelvin : ", kel)

def reamur(r):
    cel = (5 / 4) * r
    fahre = (9 / 4) * r + 32
    kel = (5 / 4) * r + 273
    print("reamur dalam celcius : ", cel)
    print("reamur dalam fahrenheit : ", fahre)
    print("reamur dalam kelvin", kel)

def fahrenheit(f):
    cel = (5 / 9) * (f - 32)
    rea = (4 / 9) * (f - 32)
    kel = (5 / 9) * (f - 32) + 273
    print("fahrenheit dalam celcius : ", cel)
    print("fahrenheit dalam reamur : ", rea)
    print("fahrenheit dalam kelvin", kel)

def kelvin(k):
    celc = k - 273
    fahr = (9 / 5) * (k - 273) + 32
    rea = (4 / 5) * (k - 273)
    print("kelvin dalam celcius : ", celc)
    print("kelvin dalam fahrenheit : ", fahr)
    print("kelvin dalam reamur", rea)

while input("Ketik ya untuk melanjutkan : ") == pilihan:

    a = str(input("Pilih suhu : "))
    b = int(input("Masukkan angka : "))

    if a == "celcius":
      print(celcius(b))
    elif a == "reamur":
        print(reamur(b))
    elif a == "fahrenheit":
        print(fahrenheit(b))
    elif a == "kelvin":
        print(kelvin(b))
    else:
        print("Yang anda masukkan salah")

print("terima kasih")
print(" ")

# soal 2
print("Bilangan Fibonacci")

def fibonacci(x):
    if x == 0:
        return 0
    elif x == 1:
        return 1
    else:
        return fibonacci(x-1) + fibonacci(x-2) 

c = int(input("Masukkan bilangan fibonacci : "))

for i in range(c):
    print(fibonacci(i))
print((" "))

# soal 3
print("SEGITIGA BINTANG")
def segitiga(x):
    for i in range(1, x + 1):
        print(i * "*")

x = int(input("masukkan tinggi segitiga bintang : "))
y = int(input("masukkan jumlah segitiga yang ingin ditampilkan : "))

for y in range(y):
    segitiga(x)
print(" ")